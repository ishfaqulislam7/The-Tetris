#include "position.h"

Position::Position(int row, int column)
{
    this->row = row;
    this->column = column;
}